package hr.ferit.magdalenabaric.myapplication_final

data class Dog(
    var id : String = "",
    val name : String? =null,
    val breed: String? = null,
    val color: String? =null,
    val height: String? =null,
    val personality: String? =null
)
